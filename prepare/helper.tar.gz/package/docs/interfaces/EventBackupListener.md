[Helper Interfaces](../README.md) / EventBackupListener

# Interface: EventBackupListener

## Hierarchy

- `Listener`

  ↳ **`EventBackupListener`**

## Callable

### EventBackupListener

▸ **EventBackupListener**(): `Record`<`string`, `any`\> \| `Promise`<`Record`<`string`, `any`\>\>

#### Returns

`Record`<`string`, `any`\> \| `Promise`<`Record`<`string`, `any`\>\>

Backup data of the component to save with the session data

### EventBackupListener

▸ **EventBackupListener**(): `never`

**`deprecated`** This function is only for making the interface *callable*

#### Returns

`never`
