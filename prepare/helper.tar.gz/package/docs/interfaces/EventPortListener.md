[Helper Interfaces](../README.md) / EventPortListener

# Interface: EventPortListener

## Hierarchy

- `Listener`

  ↳ **`EventPortListener`**

## Callable

### EventPortListener

▸ **EventPortListener**(`data`): `void`

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `data` | `string` | New data from the port |

#### Returns

`void`

### EventPortListener

▸ **EventPortListener**(): `never`

**`deprecated`** This function is only for making the interface *callable*

#### Returns

`never`
