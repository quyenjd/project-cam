[Helper Interfaces](../README.md) / EventErrorListener

# Interface: EventErrorListener

## Hierarchy

- `Listener`

  ↳ **`EventErrorListener`**

## Callable

### EventErrorListener

▸ **EventErrorListener**(`error`): `void`

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `error` | `string` | Message from the application |

#### Returns

`void`

### EventErrorListener

▸ **EventErrorListener**(): `never`

**`deprecated`** This function is only for making the interface *callable*

#### Returns

`never`
