# Project CAM: Helper

A piece of code to be prepended to the source of the components every time they are loaded. This is to provide a way of establishing a connection between the components and the application. Also, typing is available to help with component development.

To build, simply run `npm run build`. This will build the Helper utility, as well as pack it and then send it to the directory of the `prepare` tool.

## Author

Quyen Dinh, AI team.